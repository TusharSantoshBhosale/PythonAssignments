
def Phoenix():
    print("Inside Phoenix")
    
    def zara():
        print("Inside Zara")

def main():
    Phoenix.zara()

if __name__ == "__main__":
    main()