print("Enter First Numbr : ")
No1 = int(input())

print("Enter First Numbr : ")
No2 = int(input())

print(type(No1))
print(type(No2))    

Ans =  No1 + No2

print("Addition is : ",Ans)