def Addition(No1,No2):
    Ans = None
    Ans = No1 + No2
    return Ans

Result = Addition(10,11)
print("Addition is : ",Result)