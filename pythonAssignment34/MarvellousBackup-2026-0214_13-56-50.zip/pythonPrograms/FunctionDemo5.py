#Accept : One parameter
#Return : Nothing

def Marvellous1(Value):
    print("Inside Marvellous1 : ",Value)


def main():
    Marvellous1("Python")
    Marvellous1(51)

if __name__ == "__main__":
    main()