Age = 5         #int
Marks = 90.89   #float
City = "Pune"   #str
Food = False    #bool
Complex = 7+9j  #complex

print(type(Age))
print(type(Marks))
print(type(City))
print(type(Food))
print(type(Complex))