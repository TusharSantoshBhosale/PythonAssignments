if __name__ == "__main__":
    print("self executable file")
else:
    print("moduled file")