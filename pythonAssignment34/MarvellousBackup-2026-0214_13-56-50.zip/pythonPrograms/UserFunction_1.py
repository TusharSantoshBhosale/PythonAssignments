def Multiplication(Value1,Value2):
    Ans=0
    Ans = Value1 * Value2
    return Ans

print("Demo Application")

