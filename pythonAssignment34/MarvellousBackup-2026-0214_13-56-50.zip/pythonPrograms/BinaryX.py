#Indexed
#Orderd
#Immutable

Data = bytes([65,97,98])

print(Data)
print(type(Data))
print(Data[0])

#Data[0] = 66 Error
print(Data[0])