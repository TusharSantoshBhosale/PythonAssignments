#Accept : Nothing
#Return : Nothing

def Marvellous1():
    print("Inside Marvellous1")


def main():
    Marvellous1()

if __name__ == "__main__":
    main()