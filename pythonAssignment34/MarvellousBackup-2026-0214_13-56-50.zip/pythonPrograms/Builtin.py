import math

result = math.sqrt(16)

print("Square root is : ",result)