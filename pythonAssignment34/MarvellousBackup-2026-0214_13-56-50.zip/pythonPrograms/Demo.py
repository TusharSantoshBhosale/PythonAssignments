print("Marvellous Infosystem")
print("Pune")
print("Maharashtra")
print("India")