## Not a good programming practice
def main():
    print("Inside main")
    pass

if __name__ == "__main__":
    main()