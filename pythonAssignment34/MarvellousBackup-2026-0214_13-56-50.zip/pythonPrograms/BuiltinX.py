from math import sqrt

result = sqrt(16)

print("Square root is : ",result)