arr = {10,20,30,40,10}
print("-"*15)
print(arr)
print(type(arr))
print("-"*15)
print("_______________________________")

book  = {"Name" : "Let us C", "Price" : 350, "Author" : "Y kanetkar"}
print("-"*15)
print(book)
print(type(book))
print(book["Price"])
print("-"*15)   
print("_______________________________")