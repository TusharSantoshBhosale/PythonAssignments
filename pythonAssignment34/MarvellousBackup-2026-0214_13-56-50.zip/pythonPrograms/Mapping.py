Information = {"Name" : "Rahul","Age":25,"City":"Pune","Marks":89.90}
print(Information)
print(type(Information))

print(Information["City"])