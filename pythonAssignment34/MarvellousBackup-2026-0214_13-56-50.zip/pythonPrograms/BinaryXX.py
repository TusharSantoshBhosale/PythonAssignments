#Indexed
#Orderd
#mutable

Data = bytearray([65,97,98])

print(Data)
print(type(Data))
print(Data[0])

Data[0] = 66 
print(Data[0])