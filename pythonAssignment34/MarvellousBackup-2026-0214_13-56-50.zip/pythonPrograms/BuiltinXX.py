from math import *

result = sqrt(16)

print("Square root is : ",result)