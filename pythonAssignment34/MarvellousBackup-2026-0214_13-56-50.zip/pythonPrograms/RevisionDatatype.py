#Numaric Datatypes

No = 11
print(No)
print(type(No))
print("____________________________________________")

Marks = 90.78
print(Marks)
print(type(Marks))
print("____________________________________________")

x = 3 + 4j
print(x)
print(type(x))
print("____________________________________________")

