#Numaric

Age = 35
Marks = 89.78
Data = 8+7j

print("Age is : ",Age)
print("Marks is : ",Marks)
print("Complex : ",Data)