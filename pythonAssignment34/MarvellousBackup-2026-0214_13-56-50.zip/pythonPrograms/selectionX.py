no1 = 21
no2 = 11

print(no1>no2)