#Sequence
print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")

#Iteration
print("---------------------------------")
for i in range(4):
    print("Jay Ganesh")