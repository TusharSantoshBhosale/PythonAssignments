#Accept : Multiple parameters
#Return : Nothing

def Marvellous1(Value1,Value2):
    print("Inside Marvellous1 : ",Value1, Value2)


def main():
    Marvellous1("Python",21)

if __name__ == "__main__":
    main()