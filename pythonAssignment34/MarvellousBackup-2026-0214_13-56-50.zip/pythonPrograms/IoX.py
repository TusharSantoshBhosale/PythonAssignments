
Name = input("Enter your Name : ")
print("Hello ",Name)

Age=input("Enter Your Age : ")
print("Your Age is : ",Age)