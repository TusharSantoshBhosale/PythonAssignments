#Scripting appraoch

No = 22

if No % 2 == 0 :
    print("Even Number")
else:
    print("Odd number")