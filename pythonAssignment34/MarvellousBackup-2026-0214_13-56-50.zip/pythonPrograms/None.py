Data = None
print(Data)
print(type(Data))

Data = "Tushar"
print(Data)