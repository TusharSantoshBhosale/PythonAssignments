def EmployeeInfo(Name, Age, Salary, City):
    print("Name : ",Name)
    print("Age : ",Age)
    print("Salary : ",Salary)
    print("City : ",City)


def main():
    #Positional Argument
    #EmployeeInfo("Rahul",26,2000.50,"Pune") #Correct
    #EmployeeInfo(26,"Rahil","Pune",2000.50) #Wrong

    #Keyword Argument
    EmployeeInfo(Age=26, Name="Rahil", City="Pune", Salary=2000.50)

if __name__ == "__main__":
    main()