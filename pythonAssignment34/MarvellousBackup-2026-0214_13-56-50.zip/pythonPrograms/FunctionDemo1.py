
def main():
    print("Enter in main")

if __name__ == "__main__":
    main()