no1 = 11
no2 = 21

if no1 > no2 :
    print("No1 is greater")
else:
    print("No2 is greater")