import sys

No = 11         #int
No = 565654844654654654654654646546468465465465465465
Marks = 90.90   #float

Name = "Rahul"  #str

print(sys.getsizeof(No))
print(sys.getsizeof(Marks))
print(sys.getsizeof(Name))