print("Enter your Name : ")
Name = input()

print("Hello ",Name)

print("Enter Your Age : ")
Age=input()

print("Your Age is : ",Age)