PI = 3.14
print("Inside Module : ",__name__)

def Add(No1,No2):
    Ans = 0
    Ans = No1 + No2
    return Ans

def Sub(No1,No2):
    Ans = 0
    Ans = No1 - No2
    return Ans

