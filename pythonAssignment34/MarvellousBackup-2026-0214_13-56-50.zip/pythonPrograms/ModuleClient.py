import Marvellous

print("Inside Client : ",__name__)
print("Value of PI is :",Marvellous.PI)

Result = 0

Result = Marvellous.Add(10,11)
print("Addition is : ",Result)

Result = Marvellous.Sub(10,11)
print("Substraction is : ",Result)