No = 11     #Global

def Fun():
    print("Value of No from Fun is : ",No)

print("Value of No is : ",No)
Fun()