Data = bytes([65])

print(Data)
print(type(Data))