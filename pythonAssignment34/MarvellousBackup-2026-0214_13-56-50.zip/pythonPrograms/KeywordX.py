def EmployeeInfo(Name, Age, Salary, City):
    print("Name : ",Name)
    print("Age : ",Age)
    print("Salary : ",Salary)
    print("City : ",City)


def main():

    EmployeeInfo(Age=26, Name="Rahil", City="Pune", Salary=None)

if __name__ == "__main__":
    main()