Information = {"Name" : "Rahul","Age":25,"City":"Pune","Marks":89.90,"City":"Mumbai"}

print(Information)

print(Information["City"])

Information["Age"] = 26
print(Information)