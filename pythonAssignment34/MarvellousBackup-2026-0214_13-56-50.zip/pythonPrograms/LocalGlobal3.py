No = 11     #Global

def Fun():
    No = 21
    print("Value of No from Fun is : ",No)
    No += 1
    print("Value of No from Fun is : ",No)

print("Value of No is : ",No)
Fun()
print("Value of No is : ",No)