import math as m

result = m.sqrt(16)

print("Square root is : ",result)