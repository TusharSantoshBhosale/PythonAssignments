def EmployeeInfo(Name, Age, Salary, City = "Pune"):
    print("Name : ",Name)
    print("Age : ",Age)
    print("Salary : ",Salary)
    print("City : ",City)


def main():
    EmployeeInfo("Rahul",26,Salary=2000.50)

if __name__ == "__main__":
    main()