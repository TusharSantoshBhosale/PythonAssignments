def multiplication(No1,No2):
    Ans = No1 * No2
    return Ans

print("Enter first number : ")
No1 = int(input())

print("Enter second number : ")
No2 = int(input())

Result = multiplication(No1,No2)

print("multiplication is : ",Result)