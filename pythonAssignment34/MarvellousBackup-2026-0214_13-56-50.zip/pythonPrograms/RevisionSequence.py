#Sequence Datatype

arr = [10,20,30,40,10]
print(arr)
print(type(arr))
print("_______________________________")

brr = (10,20,30,40,10)
print(brr)
print(type(brr))
print("_______________________________")