
def Phoenix():
    print("Inside Phoenix")
    
    def zara():
        print("Inside Zara")

    zara()

def main():
    Phoenix()

if __name__ == "__main__":
    main()