Data = [10,20,30,40,50]

print(type(Data))
print(len(Data))
print(Data)

print(Data[0])
print(Data[1])
print(Data[2])
print(Data[3])
print(Data[4])