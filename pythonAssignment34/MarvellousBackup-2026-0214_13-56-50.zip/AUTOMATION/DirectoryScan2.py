
import os
def DirectoryScanner(DirectoryName):

    for FolderName, SubFolderName, FileName in os.walk(DirectoryName):
        print("Folder Name : ",FolderName)

        for Subf in SubFolderName:
            print("SubFolder Name : ",Subf)

        for fName in FileName:
            print("File Name : ",fName)


def main():
    DeirectoryName = input("Enter the name of directory : ")

    print("Contents of the directory are : ")

    if(os.path.exists(DeirectoryName)):
        DirectoryScanner(DeirectoryName)
    else:
        print("There is no such DirectoryName")
    

if __name__ == "__main__":
    main()

if __name__ == "__main__":
    main()
