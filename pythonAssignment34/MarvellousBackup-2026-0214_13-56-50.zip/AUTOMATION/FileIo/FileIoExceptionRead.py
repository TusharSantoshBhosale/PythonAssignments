
def main():
 
    try:
        fObj = open("Hello.txt","r")
        print("File gets successfully opened")

        Data = fObj.read()
        print("Data from file is : ",Data)
        fObj.close()

    except FileNotFoundError:
        print("Unable to open file as there is no such file")
    finally:
        print("End of Application")

if __name__ == "__main__":
    main()