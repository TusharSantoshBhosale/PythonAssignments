#sekk(Kuthe , Kuthun)
#Kuthun:0/1/2
# 0 : Starting
# 1 : Current
# 2 : End

def main():
 
    try:
        fObj = open("Hello.txt","r")
        print("File gets successfully opened")
        print("Current offet is : ",fObj.tell())    # 0
        fObj.seek(7,0)
        
        print("Current offet is : ",fObj.tell())    # 7

        Data = fObj.read(10)       
        
        print("Current offet is : ",fObj.tell())    # 17

        print("Data from file is : ",Data)
        fObj.close()

    except FileNotFoundError:
        print("Unable to open file as there is no such file")
    finally:
        print("End of Application")

if __name__ == "__main__":
    main()