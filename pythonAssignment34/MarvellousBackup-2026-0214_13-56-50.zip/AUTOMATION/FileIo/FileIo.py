import os
def main():
    FileName = input("Enter the name of file : ")

    if(os.path.exists(FileName)):
        fobj =os.open(FileName,"w")
        print(fobj.readable())
        print(fobj.writable())
        print(fobj.seekable())

        print("File gets Deleted")
    else:
        print("There is no such file")
if __name__ == "__main__":
    main()