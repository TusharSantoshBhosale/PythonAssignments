import sys
import os

def DirectoryScanner(DirName = "Marvellous"):
    Ret = False
    Ret = os.path.exists(DirName)

    if(Ret == False):
        print("There is no such Directory")
        return
    
    Ret = os.path.isdir(DirName)

    if(Ret == False):
        print("It is not a directory")
        return
    
    for FolderName, SubFolder, FilesName in os.walk(DirName):
        for fname in FilesName:
            fname = os.path.join(FolderName,fname)
            print("File name : ",fname)
            print("File Size : ",os.path.getsize(fname))
            
            if(os.path.getsize(fname) == 0):
                os.remove(fname)

def main():
    Border = "-"*50
    print(Border)
    print("___________Marvellous Directory Automation______________")
    print(Border)

    if(len(sys.argv) != 2):
        print("Invalid Number of Arguments")
        print("Please specify the name of Directory")
        return

    DirectoryScanner(sys.argv[1])

if __name__ =="__main__":
    main()