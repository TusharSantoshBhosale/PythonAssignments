import os
def main():
    DeirectoryName = input("Enter the name of directory : ")

    print("Contents of the directory are : ")

    for FolderName, SubFolderName, FileName in os.walk(DeirectoryName):
        print("Folder Name : ",FolderName)

        for Subf in SubFolderName:
            print("SubFolder Name : ",Subf)

        for fName in FileName:
            print("File Name : ",fName)

if __name__ == "__main__":
    main()
