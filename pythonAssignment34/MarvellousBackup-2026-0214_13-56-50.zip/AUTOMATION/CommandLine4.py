#python3 ConnamdLine4.py 11 10

import sys
def main():
    Sum = 0
    No1 = int(sys.argv[1])
    No2 = int(sys.argv[2])
    Sum = No1 + No2
    print(Sum)

if __name__ =="__main__":
    main()