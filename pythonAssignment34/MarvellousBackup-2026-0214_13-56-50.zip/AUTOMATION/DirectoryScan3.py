
import os
def DirectoryScanner(DirectoryName = "Marvellous"):

    Ret = os.path.exists(DirectoryName)

    if(Ret ==  False):
        print("There is no such directory")
        return

    print("Contents of the directory are : ")


    for FolderName, SubFolderName, FileName in os.walk(DirectoryName):
        print("Folder Name : ",FolderName)

        for Subf in SubFolderName:
            print("SubFolder Name : ",Subf)

        for fName in FileName:
            print("File Name : ",fName)


def main():
    DeirectoryName = input("Enter the name of directory : ")

    DirectoryScanner(DeirectoryName)

if __name__ == "__main__":
    main()