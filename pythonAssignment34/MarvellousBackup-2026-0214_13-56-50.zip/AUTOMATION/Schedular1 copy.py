import time
import datetime

def main():
    print(time.time())
    print(time.ctime())
    print(datetime.datetime.now())

if __name__ == "__main__":
    main()