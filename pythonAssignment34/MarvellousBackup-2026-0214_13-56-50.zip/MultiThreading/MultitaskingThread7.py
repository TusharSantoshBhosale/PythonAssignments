import threading

def Display(No):
    print("Inside Display : ",No)
        
def main():
    Display(11)

if __name__ == "__main__":
    main()