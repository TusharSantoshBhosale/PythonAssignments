def SumCube(no):
    sum  = 0
    for i in range(1,no+1):
        sum = sum + (i*i*i)
    return sum

def main():
    Ret = SumCube(10)
    print(Ret)

if __name__ == "__main__":
    main()