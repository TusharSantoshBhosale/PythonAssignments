import os
def main():
    print(os.cpu_count())
if __name__ == "__main__":
    main()