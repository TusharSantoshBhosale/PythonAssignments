import threading

def SumEven(No):
    sum = 0
    for i in range(2,No+1,2):
        sum += i
    
    print("Even Sum is : ",sum)

def SumOdd(No):
    sum = 0
    for i in range(1,No+1,2):
        sum += i
    
    print("Odd Sum is : ",sum)

def main():
    SumEven(10000000)
    SumOdd(10000000)
    
if __name__ == "__main__":
    main()