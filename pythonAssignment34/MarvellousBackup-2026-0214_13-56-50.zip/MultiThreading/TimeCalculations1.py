def Factorial(No):
    fact = 1

    for i in range(No,0,-1):
        fact *= i
    
    return fact

def main():
    Value = int(input("Enter number : "))
    Ret = Factorial(Value)
    print("Factorial is : ",Ret)

if __name__ == "__main__":
    main()