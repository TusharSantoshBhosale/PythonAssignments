import sys

print("Number of Command line arguments are : ",len(sys.argv))