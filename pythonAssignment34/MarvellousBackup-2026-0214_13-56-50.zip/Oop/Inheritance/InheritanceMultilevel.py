class Parent:
    pass

class Child(Parent):
    pass

class ChildX(Child):
    pass