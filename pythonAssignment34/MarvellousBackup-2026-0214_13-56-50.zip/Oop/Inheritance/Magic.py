#Dunder Method or Magic Method Or Special Method

class Demo:
    def __init__(self, A):
        self.No = A

obj1 = Demo(11)
obj2 = Demo(21)

print(11+21)

print(obj1 + obj2)