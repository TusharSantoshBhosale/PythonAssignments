class Parent:
    def __init__(self):
        print("Inside Parent contructor")
        self.No1 = 10
        self.No2 = 20
    
    def Fun(self):
        print("Inside Fun Method of parente")

class Child(Parent):
    def __init__(self):
        super().__init__()
        print("Inside Child Contructor")
        self.A = 11
        self.B = 21
    
    def Sun(self):
        print("Inside sun Method of child")

cObj = Child()

print(cObj.No1) #10
print(cObj.No2) #20

print(cObj.A)   #11
print(cObj.B)   #21

cObj.Fun()
cObj.Sun()