No1 = 0
No2 = 0
Ans = 0

No1 =int(input("Enter the first Number : "))
No2 =int(input("Enter the second Number : "))

Ans = No1 + No2
print("Addition is : ",Ans)

Ans = No1 - No2
print("Substraction is : ",Ans)