
Addition = lambda no1,no2 : no1+no2
Substraction = lambda no1,no2 : no1-no2


No1 = 0
No2 = 0
    
No1 =int(input("Enter the first Number : "))
No2 =int(input("Enter the second Number : "))

Ret = Addition(No1,No2)  #It happense Ret = No1 + No2
print("Addtion is : ",Ret)

Ret = Substraction(No1,No2) #It happense Ret = No1 - No2
print("Substraction is : ",Ret)

