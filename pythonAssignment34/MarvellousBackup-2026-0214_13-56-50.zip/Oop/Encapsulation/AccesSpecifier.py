class Demo:
    def __init__(self):
        self.No1 = 10       #public
        self._No2 = 20      #Protected
        self.__No3 = 30     #Private

obj = Demo()