class Arithmatic:
    def Addition(self ,A,B):
        return A+B
    
    def Substraction(self ,A,B):
        return A-B

No1 = 0
No2 = 0
Ans = 0

obj = Arithmatic()

No1 =int(input("Enter the first Number : "))
No2 =int(input("Enter the second Number : "))

Ans = obj.Addition(No1,No2)
print("Addition is : ",Ans)

Ans = obj.Substraction(No1,No2)
print("Substraction is : ",Ans)