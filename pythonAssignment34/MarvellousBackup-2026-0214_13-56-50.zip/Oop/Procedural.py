
def Add(No1,No2):
    return No1+No2

def Sub(No1,No2):
    return No1-No2

def main():
    No1 = 0
    No2 = 0
    
    No1 =int(input("Enter the first Number : "))
    No2 =int(input("Enter the second Number : "))

    Ret = Add(No1,No2)
    print("Addtion is : ",Ret)

    Ret = Sub(No1,No2)
    print("Substraction is : ",Ret)

if __name__ == "__main__":
    main()