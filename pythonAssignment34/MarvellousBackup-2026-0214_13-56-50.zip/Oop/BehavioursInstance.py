
class Demo:
    No1 = 10
    def __init__(self,A,B):
        #Instance varible
        self.Value1 = A
        self.Value2 = B
    def fun(self):
        print("Inside Instance method fun : ",self.Value1,self.Value2)
    
    @classmethod
    def sun(cls):
        print("Inside class method sun : ",cls.No1)

Demo.sun()
print("Class varibale : ",Demo.No1)

obj =  Demo(11,21)

obj.fun()
print("Instance varibale : ",obj.Value1,obj.Value2)